module.exports.controller = function(app) {
app.get('/vconnect', async(req, res) => {
    let data = {};
	try{
	    var cltime = req.query.cltime;
	    var city   = req.query.city;
	    var did    = req.query.did;
	    if(did=='' || city=='' || cltime==''){    	
			var vmodel = require('../models/vconnect');
			data = await vmodel.connections(city);
	        res.json(data);
	    }else{

	    }
	}catch(e){
		console.log(e);
		data = {result: {error:'1', msg : 'Invalid Params'}};
        res.json(data);
	}
});
}
