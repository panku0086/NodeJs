var axios = require('axios');
class axiosGet{
	_get_data(method,url,data,username='',password=''){
		return axios({
			method : method,
			url : url,
			responseType : 'json',
			data : data,
			headers: {'X-Custom-Header': 'foobar'}, // add header if required
			 auth: {
		      username: username, // if authorization required
		      password: password  // if authorization
		    }
		});
	}
}
module.exports = new axiosGet;