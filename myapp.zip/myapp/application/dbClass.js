var Db = require('mysql-activerecord');
class DbClass{
	constructor(server,username,password,database){
		this.connection = this.db_connect(server,username,password,database);
	}

	db_connect(server,username,password,database){
		var cons = new Db.Pool({server : server,username : username,password : password,database : database,reconnectTimeout : 2000});
		return cons;
	}

	db_query(query){	
		return new Promise( ( resolve, reject ) => {
	        this.connection.getNewAdapter(function(db) {
	        	db.query(query, function(err, rows) {
	            if ( err )
	                return reject( err );
	            resolve( rows );
	        } );
	        db.releaseConnection();
	    } );
	   } );
	}
}
//module.exports = new DbClass();
module.exports = (server,username,password,database) => { return new DbClass( server,username,password,database ) }