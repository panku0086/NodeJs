var connection = require('../application/connection.json');
var axiosCall  = require('../application/axiosGet');
class Vconnect{
	constructor(){
		this.db_conf = connection;
	}
	
	async connections(city){

		var city     = city.toLowerCase(city);
		var server   = this.db_conf['db-vconnect-'+city+''][0];
		var username = this.db_conf['db-vconnect-'+city+''][1];
		var password = this.db_conf['db-vconnect-'+city+''][2];
		var databas  = this.db_conf['db-vconnect-'+city+''][3];
		var database = require('../application/dbClass')(server,username,password,databas);
		var data = await this.Query(database);
		return data;
	}
	async Query(database){
		var qry      = 'SELECT * FROM Table LIMIT 1';
		var results   = await database.db_query(qry);
		var numList  = [];
		let data = {};
		results.forEach(function(element) {
			  numList.push(element.CallerNumber);
		});
		if(numList.length>1){

		}else if(numList.length==1){
			var mobile = numList[0];
			if(numList[0].length>10){
				mobile = numList[0].substring(2,10);
			}
			var url  = '/assets/url';
			var user = 0; var u_data = {};
			var userExist =  await axiosCall._get_data('GET',url,'');
			user = userExist.data;
			if(user==1){
				data = {result: {error:'0', msg : 'success', mb : mobile, nm : name}};
			}else{
				
			}
	
		}else{
			data = {result: {error:'1', msg : 'No Record Found!!'}};
		}
		return data;
		//console.log(JSON.stringify(result));
		//console.log(result[0].CallerNumber);
	}
	/*async axiosCall(url){
	  return await axios.get(url)
	}*/	
}
//module.exports = (city) => { return new Vconnect( city ) }
module.exports = new Vconnect();
